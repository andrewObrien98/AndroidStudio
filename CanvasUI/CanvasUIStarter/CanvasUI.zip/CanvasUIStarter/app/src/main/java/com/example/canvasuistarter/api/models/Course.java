package com.example.canvasuistarter.api.models;

public class Course {
    public long id;
    public String name;
}
