package com.example.canvasuistarter.api.models;

public class User {
    public long id;
    public String name;
}
