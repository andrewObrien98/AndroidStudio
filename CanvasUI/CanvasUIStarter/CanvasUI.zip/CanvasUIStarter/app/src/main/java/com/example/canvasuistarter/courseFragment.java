package com.example.canvasuistarter;

import android.content.Context;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.canvasuistarter.api.USUCanvasAPI;
import com.example.canvasuistarter.api.models.Course;

public class courseFragment extends Fragment {
    public courseFragment(){
        super(R.layout.fragment_course);

    }
}
