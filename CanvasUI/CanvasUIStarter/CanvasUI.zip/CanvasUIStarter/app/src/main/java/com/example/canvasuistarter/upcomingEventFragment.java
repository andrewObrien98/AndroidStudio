package com.example.canvasuistarter;

import androidx.fragment.app.Fragment;

public class upcomingEventFragment extends Fragment {
    public upcomingEventFragment(){
        super(R.layout.fragment_upcoming_event);
    }
}
