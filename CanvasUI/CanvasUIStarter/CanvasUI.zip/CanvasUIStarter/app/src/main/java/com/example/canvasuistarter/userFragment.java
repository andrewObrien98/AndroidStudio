package com.example.canvasuistarter;

import androidx.fragment.app.Fragment;

public class userFragment extends Fragment {
    public userFragment(){
        super(R.layout.user_list_item);
    }
}
